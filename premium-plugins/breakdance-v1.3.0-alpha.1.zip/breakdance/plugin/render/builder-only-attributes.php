<?php

const BUILDER_ONLY_HTML_ATTRIBUTES = ['data-content-editable-property-path'];
