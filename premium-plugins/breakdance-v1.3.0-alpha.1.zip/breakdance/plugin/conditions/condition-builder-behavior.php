<?php

namespace Breakdance\Conditions;

\Breakdance\PluginsAPI\registerBuilderPlugin(file_get_contents(dirname(__FILE__) . '/conditionBuilderBehavior.js'));
