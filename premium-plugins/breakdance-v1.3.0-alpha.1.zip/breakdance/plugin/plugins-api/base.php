<?php

namespace Breakdance\PluginsAPI;

include __DIR__ . "/plugins-controller.php";
include __DIR__ . "/register-builder-plugin.php";
include __DIR__ . "/get-json-of-plugins.php";
