<?php

namespace Breakdance\Animations;

include __DIR__ . "/entrance/base.php";
include __DIR__ . "/scrolling/base.php";
include __DIR__ . "/sticky/base.php";
include __DIR__ . "/control.php";

