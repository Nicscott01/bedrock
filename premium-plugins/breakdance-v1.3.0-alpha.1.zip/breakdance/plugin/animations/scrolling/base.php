<?php
/**
 * Plugin Name: Breakdance AOS
 * Description: 42
 * Version: 0.1
 */

namespace Breakdance\Animations\Scrolling;

require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/control.php';
require_once __DIR__ . '/attributes.php';
require_once __DIR__ . '/dependencies.php';
require_once __DIR__ . '/actions.php';
