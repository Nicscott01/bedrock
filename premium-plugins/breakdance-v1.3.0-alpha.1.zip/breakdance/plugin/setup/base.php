<?php

namespace Breakdance\Setup;

require_once __DIR__ . "/settings-page.php";
require_once __DIR__ . "/custom-post-types.php";
require_once __DIR__ . "/activate-and-install.php";
require_once __DIR__ . "/reset-and-refresh.php";
require_once __DIR__ . "/replace-url.php";
require_once __DIR__ . "/clean-cache.php";
