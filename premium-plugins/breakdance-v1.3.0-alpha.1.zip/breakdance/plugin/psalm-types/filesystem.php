<?php

/**
 * @psalm-type FSBucket = \Breakdance\Filesystem\Consts::BREAKDANCE_FS_BUCKET_*
 * @psalm-type FSError = \Breakdance\Filesystem\Consts::BREAKDANCE_FS_ERROR_*
 */
