<?php

/**
 *
 * @psalm-type WPWidget = array{slug:string,name:string,className:string,category:string,controls:Control[]}
 *
 */

