<?php

/**
 * @psalm-type Permission = array{name:string,slug:string,level:int, overwritten?:bool}
 */
