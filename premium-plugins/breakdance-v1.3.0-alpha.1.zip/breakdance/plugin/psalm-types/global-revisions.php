<?php
/**
 * @psalm-type RevisionFromDb = array{id: string, timestamp: int, author_user_id: int}
 * @psalm-type RevisionAjaxObj = array{id: string, date: string, author: string}
 * @psalm-type RevisionData = mixed
 */
