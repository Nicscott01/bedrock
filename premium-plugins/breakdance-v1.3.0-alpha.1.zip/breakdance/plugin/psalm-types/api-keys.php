<?php

/**
 *
 * @psalm-type ApiKey = array{
 * slug:string,
 * name:string,
 * description?:string
 * }
 *
 */
