All code and other content in this folder and any subfolders that is owned by Breakdance/Soflyy is licensed under the GPL v2.

All other code from 3rd party vendors is licensed under the applicable license - see `composer.lock` for details for each vendor. Some 3rd party vendors provide a `LICENSE` file with their license that lives in the folder that contains their code.

Others do not - for those vendors, the license is listed in `composer.lock`.
