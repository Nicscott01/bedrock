<?php

namespace Breakdance\AvailableDependencyFiles;

require_once __DIR__ . "/get-local-files.php";
