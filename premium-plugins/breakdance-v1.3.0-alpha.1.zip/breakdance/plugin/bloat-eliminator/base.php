<?php

namespace Breakdance\BloatEliminator;

require_once __DIR__ . '/bloat-eliminator-actions.php';
require_once __DIR__ . '/bloat-eliminator-tab.php';
