<?php

const BREAKDANCE_ACTIVECAMPAIGN_API_KEY_NAME = 'activecampaign_api_key';
const BREAKDANCE_ACTIVECAMPAIGN_URL_NAME = 'activecampaign_url';
const BREAKDANCE_CONVERTKIT_API_KEY_NAME = 'convertkit_api_key';
const BREAKDANCE_DRIP_API_KEY_NAME = 'drip_api_key';
const BREAKDANCE_DISCORD_WEBHOOK_URL_NAME = 'discord_webhook_url';
const BREAKDANCE_SLACK_WEBHOOK_URL_NAME = 'slack_webhook_url';
const BREAKDANCE_FACEBOOK_APP_ID_NAME = 'facebook_app_id';
const BREAKDANCE_GETRESPONSE_API_KEY_NAME = 'getresponse_api_key';
const BREAKDANCE_GOOGLE_MAPS_API_KEY_NAME = 'google_maps_api_key';
const BREAKDANCE_MAILCHIMP_API_KEY_NAME = 'mailchimp_api_key';
const BREAKDANCE_MAILERLITE_API_KEY_NAME = 'mailerlite_api_key';
const BREAKDANCE_RECAPTCHA_SITE_KEY_NAME = 'recaptcha_site_key';
const BREAKDANCE_RECAPTCHA_SECRET_KEY_NAME = 'recaptcha_secret_key';
