<?php

namespace Breakdance\MaintenanceMode;

require_once __DIR__ . "/maintenance-mode.php";
require_once __DIR__ . "/maintenance-mode-tab.php";
