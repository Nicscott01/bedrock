<?php

namespace Breakdance\DynamicData;

class AcfGroupField extends AcfField {

    public function slug()
    {
        return 'acf_group_' . $this->field['key'];
    }

    /**
     * @inheritDoc
     */
    public function returnTypes()
    {
        return ['string'];
    }

    public function availableForPostType($postType)
    {
        return false;
    }

    /**
     * @inheritDoc
     */
    public function handler($attributes): StringData
    {
        return StringData::emptyString();
    }
}
