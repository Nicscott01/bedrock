<?php
namespace Breakdance\Licensing;

const BREAKDANCE_EDD_STORE_URL = 'https://breakdance.com';
const BREAKDANCE_EDD_ITEM_ID = 14;

require_once __DIR__ . "/edd_sl_plugin_updater.php";
require_once __DIR__ . "/functions.php";
require_once __DIR__ . "/on_wp_init.php";
