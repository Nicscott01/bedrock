<?php

require_once __DIR__ . "/onboarding-notice.php";
require_once __DIR__ . "/setup-wizard-page.php";
