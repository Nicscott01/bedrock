<?php

namespace Breakdance\HeaderFooterTrackingCode;

require_once __DIR__ . '/tracking-code-settings-tab.php';
require_once __DIR__ . '/tracking-code-actions.php';
