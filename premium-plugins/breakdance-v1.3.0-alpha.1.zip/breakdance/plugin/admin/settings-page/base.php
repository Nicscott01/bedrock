<?php

namespace Breakdance\Admin\SettingsPage;

require_once __DIR__ . "/api.php";
require_once __DIR__ . "/settings-page-controller.php";
require_once __DIR__ . "/settings-page.php";
require_once __DIR__ . "/tabs/license.php";
require_once __DIR__ . "/tabs/post-types.php";
require_once __DIR__ . "/tabs/advanced.php";
require_once __DIR__ . "/tabs/privacy.php";
require_once __DIR__ . "/tabs/global-styles.php";
