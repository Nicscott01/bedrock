<?php

namespace Breakdance\Admin;

require_once __DIR__ . "/menu/home.php";
require_once __DIR__ . "/menu/menu.php";
require_once __DIR__ . "/settings-page/base.php";
require_once __DIR__ . "/util.php";
require_once __DIR__ . "/quick_action_links.php";
require_once __DIR__ . "/admin_bar_menu.php";
require_once __DIR__ . "/launcher/gutenberg.php";
require_once __DIR__ . "/launcher/classic.php";
require_once __DIR__ . "/launcher/shared.php";
require_once __DIR__ . "/disable-breakdance-and-extract-content.php";
require_once __DIR__ . "/breakdance-post-state.php";
