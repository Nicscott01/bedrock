<?php

namespace Breakdance\Fonts;

class Consts
{
    public const GOOGLE_FONT_FILE = __DIR__ . '/google-font-list.json';
}
