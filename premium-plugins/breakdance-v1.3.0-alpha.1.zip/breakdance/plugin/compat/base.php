<?php

namespace Breakdance\Compat;

require_once __DIR__ . '/rankmath.php';
