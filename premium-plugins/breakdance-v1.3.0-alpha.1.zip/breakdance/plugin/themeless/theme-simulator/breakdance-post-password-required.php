<?php

namespace Breakdance\Themeless;

outputHeadHtml();
echo get_the_password_form();
outputFootHtml();

?>
