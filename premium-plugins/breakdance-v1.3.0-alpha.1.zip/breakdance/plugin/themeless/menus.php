<?php

add_theme_support('menus');
