# Breakdance Zero Theme

Entirely disables the WordPress theme system and lets you design every part of your site with Breakdance, while maintaining other theme functionality like template overrides and functions.php.

Requires Breakdance Builder to be installed and active to work.
