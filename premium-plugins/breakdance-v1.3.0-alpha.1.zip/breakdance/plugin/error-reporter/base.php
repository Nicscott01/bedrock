<?php

namespace Breakdance\ErrorReporter;

require_once __DIR__ . "/error-reporter-ajax-handler.php";
require_once __DIR__ . "/error-reporter.php";
