<?php

require __DIR__ . '/metadata.php';
require __DIR__ . '/resizer.php';
require __DIR__ . '/sizes.php';
require __DIR__ . '/svgs.php';
